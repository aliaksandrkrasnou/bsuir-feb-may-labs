import React from 'react'

function Footer() {
    return (
        <footer>
            <p>Powered by <a href="https://newsapi.org/">NewsAPI</a></p>
        </footer>
    )
}

export default Footer