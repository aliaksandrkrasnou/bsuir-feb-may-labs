import React from 'react'

function Header() {
    return (
        <header>
            <section className="app-header">
                <h1>News App React</h1>
            </section>
        </header>
    )
}

export default Header